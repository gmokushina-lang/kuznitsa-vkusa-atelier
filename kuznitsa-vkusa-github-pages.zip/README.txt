Кузница вкуса — публикация на GitHub Pages

1. Войдите в GitHub и создайте публичный репозиторий с именем kuznitsa-vkusa-atelier.
2. Распакуйте архив. Через Add file → Upload files загрузите index.html, style.css, app.js, .nojekyll и папку assets в корень репозитория. Не загружайте сам ZIP или внешнюю папку github-pages. Нажмите Commit changes.
3. Откройте Settings → Pages. В Source выберите Deploy from a branch, ветку main и папку /(root), затем Save.
4. Дождитесь публикации: GitHub покажет адрес сайта на этой странице.

Адрес: https://ВАШ-ЛОГИН.github.io/kuznitsa-vkusa-atelier/
Служебный адрес Sites с gmokushina в этом комплекте не используется. В адресе GitHub будет ваш логин GitHub. Для адреса только с названием бренда потребуется собственный домен.

Сборка и установка программ не нужны. Все пути к изображениям относительные.
Контакт: Марина, +7 977 674 3134. Кнопки Telegram и WhatsApp уже настроены.

Документация: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
